﻿// See https://aka.ms/new-console-template for more information


using System;


partial class Program
{
    //Declaration = new datatype
    delegate void Compute(int n1, int n2);
    delegate void Contractor(double budget);
    delegate void Work123(string s1, bool t);

    static void Main()
    {
        Action<string, bool> Work = new Action<string, bool>
            ((s, t) =>
            {
                Console.WriteLine($"work is : {s} and {t}");
            });
        Work("coding in C#", true);

        Func<string,string> Print = (str) => $"Name is: {str}";
        Console.WriteLine(Print("Dhanush"));

    }

    private static void UsingGenericDelegate()
    {
        Action<double> RockRaniRegisterMarriage = new Action<double>(
                    (budget) =>
                    {
                        Console.WriteLine($"Registration charges: {budget * 95 / 100}");
                        Console.WriteLine($"Reception Charges: {budget * 5 / 100}");
                    });

        Func<int, int, string> modifiedCompute = (n1, n2) => $"Addition: {n1 + n2}";
        modifiedCompute += (n1, n2) => $"Substraction: {n1 - n2}";

        Predicate<int> isActive = (v) =>
        {
            if (v == 0) return false;
            else return true;
        };


        //Invoke all above delegates
        RockRaniRegisterMarriage(50000d);
        Console.WriteLine(modifiedCompute(100, 200));
        Console.WriteLine($"Output of predicate: {isActive(1)}");
    }

    private static void RakiRaniMarriageDelegate()
    {
        Contractor RockeyRaniMarriage = new Contractor((b) => Console.WriteLine($"Pandith Charges: {b * 20 / 100}"));
        RockeyRaniMarriage += (b) => Console.WriteLine($"Catering Charges: {b * 50 / 100}");
        RockeyRaniMarriage += (b) => Console.WriteLine($"Mandap Decoration: {b * 5 / 100}");
        RockeyRaniMarriage += (b) => Console.WriteLine($"Couple arrive in porsche reserved for 2 days: {b * 50 / 100}");

        //Get Rockey and Rani married viz. Invoke the delegate like a function
        RockeyRaniMarriage(5000000);
    }

    private static void UsingLambdas()
    {
        //Instantiation
        Compute objShortCompute = new Compute((a, b) => Console.WriteLine($"Addition: {a + b}"));
        objShortCompute += (s, t) => Console.WriteLine($"Substraction: {s - t}");
        objShortCompute += (a, b) => Console.WriteLine($"Multiplication: {a * b}");
        objShortCompute += (s, t) => Console.WriteLine($"Division: {s / t}");

        //Invocation like calling a function
        objShortCompute(250, 100);
    }

    private static void DelegatesUsingLongCutTechnique()
    {
        //instantiate
        Compute objCompute = new Compute(AddFn);

        objCompute += SubFn;
        objCompute += MulFn;
        objCompute += DivFn;

        //Invoke the delegate exactly like a function
        objCompute(100, 200);
    }


    static void DivFn(int n1, int n2)
    {
        Console.WriteLine($"Output of division: {n1 / n2}");
    }

    static void MulFn(int n1, int n2)
    {
        Console.WriteLine($"Output of Multiplication: {n1 * n2}");
    }

    static void SubFn(int n1, int n2)
    {
        Console.WriteLine($"Output of Substraction: {n1 - n2}");
    }

    static void AddFn(int n1, int n2)
    {
        Console.WriteLine($"Output of Addition: {n1 + n2}");
    }
}
