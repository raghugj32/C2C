﻿namespace ShapeLib
{
    public class Rectangle : Paint, IShape
    {
        public int Length { get; set; }
        public int Breadth {  get; set; }

        public override string CalculateArea()
        {
            return $"The Area of Rectangle is: {Length * Breadth}";
        }

        public void Draw()
        {
            Console.WriteLine("Drawing Rectangle");
        }

        public override string FillColor(string color)
        {
            return $"Filling Rectangle with Color: {color}";
        }

        public void GetDetails()
        {
            Console.WriteLine($"The Length of Rectangle is {Length} and Breadth of Rectangle is {Breadth}");
        }
    }
}