﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeLib
{
    public class Circle : Paint, IShape
    {
        public int Radius { get; set; }
        public override string CalculateArea()
        {
            return $" The area of Circle : {(Math.PI) * Radius * Radius}";
        }

        public void Draw()
        {
            Console.WriteLine("Drawing a Circle");
        }

        public override string FillColor(string color)
        {
            return $"Filling Circle with Color: {color}";
        }

        public void GetDetails()
        {
            Console.WriteLine($"Circle Radius is: {this.Radius}");
        }
    }
}
