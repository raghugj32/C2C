﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpLib
{
    public class RuntimePolymorphism : Talents
    {
        //Permitting different logic in derived
        public virtual string Settle()
        {
            return "Get a government job, Retire by 60 yrs and settle in native";
        }

        public string GetMarried()
        {
            return "Match horoscope, marry person from same religion, caste, settle in joint family";
        }

        public override string Drawing()
        {
            return "Drawing portraits, Tanjore Paintings";
        }


        public override string WhatIsDating()
        {
            return "Meeting friends at restaurant";
        }
    }

    public class Child : RuntimePolymorphism
    {
        public override string Drawing()
        {
            return "Drawing Abstract Art, Mandala Art";
        }

        public override string WhatIsDating()
        {
            return "Use tinder App";
        }
        public override string Settle()
        {
            string howToLive = "Get a fat salaried job in fortune 500 company, visit different countries, live outside hometown";
            howToLive = $"{howToLive} and later follow this : {base.Settle()}";
            return howToLive;
        }

        //function hiding
        new public string GetMarried()
        {
            return "Register marriage, Surprise parents and settle abroad";
        }
    }

    //abstract ==Incomplete
    public abstract class Talents
    {
        public string GetDetails()
        {
            return $"Get the details of Employee";
        }
        public abstract string WhatIsDating();
        public abstract string Drawing();
    }
     
}
