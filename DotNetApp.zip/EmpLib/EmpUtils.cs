﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpLib
{
    public class EmpUtils
    {
        public static List<Employee> EmpDb { get; set; } = new List<Employee>();
        public static int Empcount {  get; set; }
        public static void Log<R>(R[] pValues)
        {
            string result = "";
            foreach (var item in pValues)
            {
                result = $"{result},{item}";
            }

            var finalResult = $"[{DateTime.Now.ToString()}] : {result}";
            //console logging
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("---------------");
            Console.WriteLine(finalResult);

            //output window
            Debug.WriteLine("------LOG------");
            Debug.WriteLine(finalResult);
        }
    }
}
