﻿// See https://aka.ms/new-console-template for more information

using EmpLib;

Person Rohith = new Person();
Rohith.Name = "Rohith";
Console.WriteLine(Rohith.Eat());

Person Vidya = new Person();
Vidya.Name = "Vidya";
Console.WriteLine(Vidya.Work());


//Base = new Derived()
Person Rushab = new Employee() { Designation = "Intern", DOJ = DateTime.Now.AddMonths(-1) };
Rushab.Name = "Rushab";
((Employee)Rushab).Designation = "Analyst";
Console.WriteLine(Rushab.Work());
Console.WriteLine($"EmpId for {Rushab.Name} is {((Employee)Rushab).EmpId}");

Console.WriteLine(((Employee)Rushab).AttendTraining("C2C"));

//Polymorphism
RuntimePolymorphism SharmajisFather = new RuntimePolymorphism();
Console.WriteLine($"Sharmaji's Father: {SharmajisFather.Settle()}");
Console.WriteLine($"sharmaji's father gets married: {SharmajisFather.GetMarried()}");
Console.WriteLine($"Sharmaji's Father's concept of Drawing(Using abstract): {SharmajisFather.Drawing()}");
Console.WriteLine($"Sharmaji's Father's concept of Dating(Using abstract): {SharmajisFather.WhatIsDating()}");

//using virtual modifications are allowed using override. Overriden behaviour is executed as below
RuntimePolymorphism Sharmaji = new Child();
Console.WriteLine($"sharmaji: {Sharmaji.GetMarried()}");
Console.WriteLine($"Sharmaji get married: {Sharmaji.GetMarried()}");
Console.WriteLine($"Sharmaji's concept of Drawing(Using abstract): {Sharmaji.Drawing()}");
Console.WriteLine($"Sharmaji's concept of Dating(Using abstract): {Sharmaji.WhatIsDating()}");

//No virtual, modification disallowed by base class, forced modify using "new" keyword. Forced execution of derived class
//using typecasting ((child)SharmajiV2).GetMarried()
RuntimePolymorphism SharmajiV2 = new Child();
Console.WriteLine($"SharmajiV2 gets married: {((Child)SharmajiV2).GetMarried()}");

//see overloading compile-time polymorphism below
Employee Param = new Employee();
Param.Name = "Param";
Param.Designation = "Security system Analyst";
Console.WriteLine(Param.Work());
Console.WriteLine(Param.Work("Solving bugs"));

//Exposing non-public information through public methods
Employee Srikar = new Employee();
Srikar.Name = "Srikar";
Srikar.SetTaxInfo("I'm Eligible in the 20% tax payers category");
Console.WriteLine(Srikar.GetTaxInfo());

//Test calling one constructor from another
Person Sricharan = new Person("345654367896", "+91 9876567898");
//This constructor should call the constructor that sets aadhar numbur
Console.WriteLine($"Aadhar Sricharan : {Sricharan.Aadhar} | Mobile Number: {Sricharan.MobileNumber}");

Console.WriteLine($"Total Employee Count: {EmpUtils.Empcount}");

//Adding Employee to a Temporary db - using state List<Employee>
EmpUtils.EmpDb.Add(Srikar);
EmpUtils.EmpDb.Add(Param);
EmpUtils.EmpDb.Add(new Employee("4637827398273", "+91 8494849384") { Name = "Manoj", Designation = "Analyst", Salary = 60202});
EmpUtils.EmpDb.Add(new Employee("4630940232273", "+91 8403923024") { Name = "Samprith", Designation = "Analyst", Salary = 80800 });
EmpUtils.EmpDb.Add(new Employee("5647839273939", "+91 9837283384") { Name = "Vidya", Designation = "Sr. Analyst", Salary = 908878 });

//Get all Employee Whoose Aadhar card starts with 46

var resultList = EmpUtils.EmpDb.Where((emp) =>emp.Aadhar != null && emp.Aadhar.StartsWith("46"));
resultList.ToList().ForEach((emp) => Console.WriteLine($"{emp.Name} | {emp.Aadhar}"));


//Get all employee with salary greater than 60K
var res = EmpUtils.EmpDb.Where((emp) => emp.Salary != null && emp.Salary > 70000);
res.ToList().ForEach((emp) => Console.WriteLine($"{emp.Name} | {emp.Salary}"));
