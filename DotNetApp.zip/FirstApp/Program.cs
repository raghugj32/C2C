﻿// See https://aka.ms/new-console-template for more information


using System.Diagnostics;

working();
ConversionOfTypes();
WorkingWithArrays();
WorkingWithCollections();

void working()
{
    Console.WriteLine("Hello, World!");

    // working with data types
    int num1 = 10;
    int num2 = 10;
    Console.WriteLine("sum = " + (num1 + num2));

    //Declaration - alternative way
    var num3 = 20;
    var formattedFloat = 200f;
    var formattedDouble = 200d;
    var formattedDecimal = 200m;

    Console.WriteLine(num3.GetType().Name);
    Console.WriteLine(formattedFloat.GetType().Name);
    Console.WriteLine(formattedDouble.GetType().Name);
    Console.WriteLine(formattedDecimal.GetType().Name);

    var s = "vidya";
    Console.WriteLine(s.GetType());

    //concatination using string interpolation

    Console.WriteLine($"the datatype of num3 is {num3.GetType().Name}");
    Console.WriteLine($"the datatype of formattedFloat is {formattedFloat.GetType().Name}");
    Console.WriteLine($"the datatype of formattedDouble is {formattedDouble.GetType().Name}");
    Console.WriteLine($"the datatype of formattedDecimal is {formattedDecimal.GetType().Name}");

    //other types

    bool isok = true;
    string msg = "hello welcome";
    char iamsingle = 's';

    Console.WriteLine($"value of {nameof(isok)} is {isok}");

}



void ConversionOfTypes()
{
    int num1 = 10;
    double num2 = 10;
    bool isok = true;
    string str = "hello";
    string strNum = "100";

    var result1 = (double)num1;
    var result2 = (int)num2;
    // var result3 = (string)isok; //string on heap and bool on stack. hence error in casting

    var convert1 = Convert.ToString(num1);
    var convert2 = Convert.ToInt32(strNum);
    //var convert3 = Covert.ToInt32(str); //Error at runtime
}

void WorkingWithArrays()
{
    int[] arr = new int[3];
    arr[0] = 10;
    arr[1] = 20;
    arr[2] = 30;

    for(int i = 0; i < arr.Length; i++)
    {
        Console.WriteLine($"value of item: {arr[i]}");
    }

    string[] greetings = { "Hi", "hello", "gm" };

    int c = 0;
    while( c < greetings.Length )
    {
        Console.WriteLine($"items of array: {greetings[c]}");
        c++;
    }
    int[] evens = { 2, 4, 6, 8 };
    int d = 0;
    do
    {
        Console.WriteLine(evens[d++]);
    } while (d<evens.Length);


    object[] objArray = {100, "ok", new int[] {1,2,3,4,5}};

    foreach(var s in objArray)
    {
        if (s.GetType().Name == "Int32[]")
        {
            foreach (var item in (Int32[])s)
            {
                Console.WriteLine(item);
            }
        }
        else
        {
            Console.WriteLine($"simple item in {nameof(objArray)}: {s}");
        }
    }
}

void WorkingWithCollections()
{
    List<string> ShoppingList = new List<string>();
    Console.WriteLine($"Total items in shopping bag: {ShoppingList.Count}");
    ShoppingList.Add( "Bags" );
    Log(new object[] { "Item added: ", ShoppingList[0] });
    ShoppingList.Add("Dresses");
    Log(new object[] { "Item added: ", ShoppingList[0] });
    ShoppingList.Add("Shoes");
    Log(new object[] { "Item added: ", ShoppingList[0] });
    //print
    PrintValues( ShoppingList );
    Console.WriteLine($"total items in shopping bag: {ShoppingList.Count}");
    ShoppingList.Remove("Shoes");
    Console.WriteLine($"total items in shopping bag: {ShoppingList.Count}");

    /////
    /////
    Print(new object[] {"comma-separated value of shopping list",
                           ShoppingList[0],
                           ShoppingList[1],
                        "\n the total count of items is: ",
                            ShoppingList.Count()});

}

//generic function to display values
void PrintValues<T>(List<T> pCollection)
{
    //use code snippet: foreach
    foreach(var item in pCollection)
    {
        Console.WriteLine(item);
    }
}

void Log<R>(R[] pValues)
{ 
    string result = "";
    foreach (var item in pValues)
    {
        result = $"{result},{item}";
    }
    
    var finalResult = $"[{DateTime.Now.ToString()}] : {result}";
    //console logging
    Console.ForegroundColor = ConsoleColor.Yellow;
    Console.WriteLine("---------------");
    Console.WriteLine(finalResult);

    //output window
    Debug.WriteLine("------LOG------");
    Debug.WriteLine(finalResult);
}


void Print(object[] pValues)//we can also use" void Print<T>(T[] pValues) " 
{
    string result = "";
    foreach (var item in pValues)
    {
        result = $"{result},{item}";
    }
    result = result.TrimStart(',');
    
    Console.WriteLine(result);
}


class Utils
{

}