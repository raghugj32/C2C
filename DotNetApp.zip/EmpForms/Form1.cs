using EmpLib;

namespace EmpForms
{
    public partial class Form1 : Form
    {
        Employee KpmgEmp = new Employee();
        public Form1()
        {
            InitializeComponent();
            button1.Click += button1_Click2;
            button1.Click += button1_Click3;

            KpmgEmp.Join += Srikar_Join;
            KpmgEmp.Join += Rohith_Join;
            KpmgEmp.Join += Vidya_Join;

            KpmgEmp.Resign += Srikar_Resign;
            KpmgEmp.Resign += Rohith_Resign;
        }

        private void Rohith_Resign(object? sender, EventArgs e)
        {
            MessageBox.Show("Rohith resigned the KPMG Successfully");
        }

        private void Srikar_Resign(object? sender, EventArgs e)
        {
            MessageBox.Show("Srikar resigned the KPMG Successfully");
        }

        private void Vidya_Join(object? sender, EventArgs e)
        {
            MessageBox.Show("Vidya joined the KPMG Successfully");
        }

        private void Rohith_Join(object? sender, EventArgs e)
        {
            MessageBox.Show("Rohith joined the KPMG Successfully");
        }

        private void KpmgEmp_Join1(object? sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void KpmgEmp_Join(object? sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void Srikar_Join(object? sender, EventArgs e)
        {
            MessageBox.Show("srikar joined the KPMG Successfully");
        }

        private void button1_Click(object? sender, EventArgs e)
        {
            MessageBox.Show("I am Subscriber 1 of click event");
        }

        private void button1_Click2(object sender, EventArgs e)
        {
            MessageBox.Show("I am Subscriber 2 of click event");
        }

        private void button1_Click3(object sender, EventArgs e)
        {
            MessageBox.Show("I am Subscriber 3 of click event");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            KpmgEmp.TriggerJoinEvent();
            //Srikar_Join(null, null);
            //Vidya_Join(null, null);
            //Rohith_Join(null, null);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            KpmgEmp.TriggerResignEvent();
        }
    }
}