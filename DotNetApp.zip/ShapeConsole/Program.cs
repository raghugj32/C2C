﻿// See https://aka.ms/new-console-template for more information

using ShapeLib;

//Circle
Circle s1 = new Circle();
s1.Radius = 8;
s1.Draw();
s1.GetDetails();
Console.WriteLine(s1.CalculateArea());
Console.WriteLine(s1.FillColor("Blue"));

//Rectangle
Rectangle s2 = new Rectangle();
s2.Length = 6;
s2.Breadth = 12;
s2.Draw();
s2.GetDetails();
Console.WriteLine(s2.CalculateArea());
Console.WriteLine(s2.FillColor("Grey"));